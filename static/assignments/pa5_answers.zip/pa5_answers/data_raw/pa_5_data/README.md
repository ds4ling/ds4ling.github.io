lang_data_raw 
=============

## Codebook

- id: (character), participant id, gender, age
- iq: (numeric), score from IQ test. 
- lang_ap: (numeric), score from language aptitude test (max score = 60)
- prof: (numeric), score on language proficiency test (percentage)
